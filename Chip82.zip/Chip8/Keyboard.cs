namespace Chip8
{
    class Keyboard
    {
        
    }
    
}